﻿namespace LibraProgramming.Windows.Interaction
{
    public class InteractionRequestContext
    {
        public static readonly InteractionRequestContext Empty = new InteractionRequestContext();
    }
}