﻿namespace RayTracing
{
    internal static class Min
    {
        public static int From(int val1, int val2) => val1 < val2 ? val1 : val2;
    }
}